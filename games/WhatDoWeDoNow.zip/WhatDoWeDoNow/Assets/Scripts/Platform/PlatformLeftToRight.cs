﻿using UnityEngine;
using System.Collections;

public class PlatformLeftToRight : MonoBehaviour {

	public Transform startMarker;
	public Transform endMarker;
	public float speed = 20.0F;
	private float startTime;
	private float journeyLength;
	public float smooth = 5.0F;
	void Start() {
		startTime = Time.time;
		journeyLength = Vector3.Distance(startMarker.position, endMarker.position);
	}
	void Update() {
		float distCovered = (Time.time - startTime) * (speed / journeyLength);
		float fracJourney = distCovered / journeyLength;
		transform.position = Vector3.Lerp(startMarker.position, endMarker.position, fracJourney);
		if (fracJourney >= 1) 
		{
			startTime = Time.time;
			Transform temp = startMarker;
			startMarker = endMarker;
			endMarker = temp;
		}
	}

	//If character collides with the platform, make it its child.
	void OnCollisionEnter2D(Collision2D col){
		if (col.gameObject.tag == "Player") {
			col.transform.parent = this.gameObject.transform; 
		}
	}

	void OnCollisionExit2D(Collision2D col){
		if (col.gameObject.tag == "Player") {
			col.transform.parent = GameObject.Find("PlayerChars").transform;
		}
	}
}