﻿using UnityEngine;
using System.Collections;

public class centerSphere : MonoBehaviour {

	public GameObject object1;
	public GameObject object2;
	private Vector3 newPos;

	void Update() {
		newPos.x = 0.5f * (object1.transform.position.x + object2.transform.position.x);
		this.transform.position = newPos;
	}
}
