﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	public float speed;					//Movement Speed
	public float jumpForce;				//Jumping Speed
	public Transform groundCheck;		//Object that checks for the ground
	private float groundRadius = 0.2f;	//The radius used to check for the ground
	public LayerMask whatIsGround;		//Indicates what we consider to be ground

	public AudioClip jump_sfx;
	public AudioClip hitHazard_sfx;
	public float AudioVolume = 0.2f;

	bool doubleJumped = false;	//Indicates whether you can double jump
	bool stopMove = true;		//Indicates whether the player should stop moving

	bool didDie = false;
	bool atDoor = false;

	//Animator variables
	Animator anim;				//animator object to store and acess the animator of the character

	void Start() {
		Messenger.AddListener("stop move", StopMove);
		Messenger.AddListener ("start move", StartMove);
		Messenger.AddListener ("start exit animation", StartExitAnimation);
		Messenger.AddListener ("start dead animation", StartDeadAnimation);
		anim = GetComponent<Animator>();

		if (GameObject.Find ("BeginningText") != null) {
			StartCoroutine(DelayForText());
		} 
		else if (GameObject.Find("EndText") != null) {
			StartCoroutine(DelayForText());
		}
		else {
			stopMove = false;
		}
	}

	// Movement
	void FixedUpdate () {
		if (!stopMove) {
			rigidbody2D.velocity = new Vector2 (Input.GetAxis ("Horizontal") * speed, rigidbody2D.velocity.y);
			if (IsGrounded ())
				doubleJumped = false;

			//Code for the walking animations
			//tests if the player is on the gound to change to the jumping animation
			if (!IsGrounded ()) {
					anim.SetBool ("jump", !IsGrounded ());
					anim.SetFloat ("Speed", 0f);
			} else {
					//make sure you are still changeing the animation while in mid air
					anim.SetBool ("jump", !IsGrounded ());
					anim.SetFloat ("Speed", Input.GetAxisRaw ("Horizontal"));
			}
			//this changes the animation from left to right or right to left base on the 
			//return from getAxisRaw
			if (Input.GetAxisRaw ("Horizontal") > 0) {
					anim.SetBool ("right", true);
			} else if (Input.GetAxisRaw ("Horizontal") < 0) {
					anim.SetBool ("right", false);
			}
		}
	}

	//Jumping
	void Update() {
		if (!stopMove) {
			if ( (IsGrounded () || !doubleJumped) && Input.GetKeyDown("space") ) {
				Vector2 vel = rigidbody2D.velocity;
				vel.y = 0;
				rigidbody2D.velocity = vel;

				AudioSource.PlayClipAtPoint(jump_sfx, Camera.main.transform.position, AudioVolume);
				rigidbody2D.AddForce(new Vector2(0, jumpForce));
				if ( !doubleJumped && !IsGrounded() )
					doubleJumped = true;
			}
		}
	}

	//Returns true if the object is grounded
	bool IsGrounded() {
		return Physics2D.OverlapCircle(groundCheck.position, groundRadius, whatIsGround);
	}

	void OnTriggerEnter2D(Collider2D col) {
		if (col.gameObject.tag == "Door" && !atDoor) {
			atDoor = true;
			Messenger.Broadcast("add door");
		}
		else if (col.gameObject.tag == "Hazard" && !didDie) {
			AudioSource.PlayClipAtPoint(hitHazard_sfx, Camera.main.transform.position);
			didDie = true;
			Messenger.Broadcast("did die");
		}
		else if (col.gameObject.tag == "HiddenBrick") {
			Destroy(col.gameObject);
		}

	}


	void OnTriggerExit2D(Collider2D col) {
		if (col.gameObject.tag == "Door" && atDoor) {
			atDoor = false;
			Messenger.Broadcast("subtract door");
		}
	}

	void StopMove() {
		Vector2 vel = rigidbody2D.velocity;
		vel.x = 0;
		rigidbody2D.velocity = vel;
		stopMove = true;
	}

	void StartMove() {
		stopMove = false;
	}

	void StartExitAnimation(){
		anim.SetBool ("nextLevel", true);
	}

	void StartDeadAnimation() {
		anim.SetBool ("dead", true);
	}

	IEnumerator DelayForText() {
		yield return new WaitForSeconds(5.5f);
		stopMove = false;
	}

}