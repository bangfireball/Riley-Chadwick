﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MenuManager : MonoBehaviour {

	public GameObject controlPanel;
	private bool onControlPanel = false;
	public AudioClip menuSelect_sfx;

	// Use this for initialization
	void Start () {
		controlPanel.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetKeyDown (KeyCode.Escape)) {
			Application.Quit();
		}

		if (onControlPanel) {
			if (Input.anyKeyDown) {
				PlayMenuSelectSound();
				controlPanel.SetActive(false);
				onControlPanel = false;
			}
		}
		else {
			if (Input.GetKeyDown(KeyCode.UpArrow)) {
				PlayMenuSelectSound();
				StartCoroutine(DelayStart ());
			}
			else if (Input.GetKeyDown(KeyCode.DownArrow)) {
				PlayMenuSelectSound();
				controlPanel.SetActive(true);
				onControlPanel = true;
			}
		}
	}

	IEnumerator DelayStart() {
		yield return new WaitForSeconds(0.5f);
		Application.LoadLevel(Application.loadedLevel+1);
	}

	void PlayMenuSelectSound() {
		AudioSource.PlayClipAtPoint(menuSelect_sfx, Camera.main.transform.position, 0.2f);
	}
}
