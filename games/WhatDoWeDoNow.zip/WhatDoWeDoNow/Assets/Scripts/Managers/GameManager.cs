﻿using UnityEngine;
using System.Collections;
using System;

public class GameManager : MonoBehaviour {

	private const int WIN_CONDITION = 0;
	private const int DEATH_CONDITION = 1;
	private int doorCount = 0;

	public AudioClip death_sfx;
	public AudioClip win_sfx;
	public float AudioVolume = 0.2f;

	// Use this for initialization
	void Start () {
		Messenger.AddListener("add door", AddDoor);
		Messenger.AddListener ("subtract door", SubtractDoor);
		Messenger.AddListener("did die", DidDie);
	}

	void Update() {
		if (Input.GetKeyDown (KeyCode.Escape)) {
			Application.LoadLevel(0);
		}
	}

	void AddDoor() {
		doorCount++;
		if (doorCount >= 2)
			DidWin ();
	}

	void SubtractDoor() {
		doorCount--;
		if (doorCount < 0)
			doorCount = 0;
	}

	public void Retry() {
		Application.LoadLevel(Application.loadedLevel);
	}


	void DidWin() {
		Messenger.Broadcast ("start exit animation");
		StartCoroutine("Delay", WIN_CONDITION);
		AudioSource.PlayClipAtPoint(win_sfx, Camera.main.transform.position, AudioVolume);
	}

	void DidDie() {
		Messenger.Broadcast ("start dead animation");
		StartCoroutine("Delay", DEATH_CONDITION);
		AudioSource.PlayClipAtPoint(death_sfx, Camera.main.transform.position);
	}

	IEnumerator Delay(int condition) {
		Messenger.Broadcast("stop move");
		yield return new WaitForSeconds(1.2f);

		if (condition == WIN_CONDITION) {
			Application.LoadLevel(Application.loadedLevel+1);
		}
		else if (condition == DEATH_CONDITION) {
			Retry ();
		}
	}
}
